package hashtable;
import java.util.*;

public class Main {

    public static void main(String[] args) {

        System.out.println("Хэш таблица");

        HashTable<String, Integer> products = new HashTable<>(10);

        products.put("Яблоки", 300);
        products.put("Бананы", 500);
        products.put("Груши", 250);
        products.put("Апельсины", 350);

        products.printTable();

        System.out.println("Задание 1:");

        String sentence1 = "Яблоки бананы груши апельсины";
        String sentence2 = "Бананы апельсины";

        String[] words1 = sentence1.toLowerCase().split("\\s+");
        String[] words2 = sentence2.toLowerCase().split("\\s+");

        HashTable<String, Boolean> wordsTable = new HashTable<>(20);

        for (String word : words2) {
            wordsTable.put(word, true);
        }

        System.out.println("Слова, которые есть в 1-ой строке, " + "но отсутствуют во второй:");

        for (String word : words1) {
            if (!wordsTable.containsKey(word)) {
                System.out.println(word);
            }
        }

        System.out.println("Задание 2:");

        int[] numbers = {2, 7, 11, 13};
        int target = 9;

        int[] result = twoSum(numbers, target);

        System.out.println("Массив: " + Arrays.toString(numbers));
        System.out.println("Target: " + target);

        if (result != null) {
            System.out.println("Индексы: (" + result[0] + ", " + result[1] + ")");

            System.out.println("Проверка: " + numbers[result[0]] + " + " + numbers[result[1]] + " = " + target);
        }
    }

    public static int[] twoSum(int[] numbers, int target) {

        HashTable<Integer, Integer> table =
                new HashTable<>(numbers.length * 2);

        for (int i = 0; i < numbers.length; i++) {

            int required = target - numbers[i];

            if (table.containsKey(required)) {

                int previousIndex = table.get(required);

                return new int[]{
                        previousIndex,
                        i
                };
            }

            table.put(numbers[i], i);
        }

        return null;
    }
}