package hashtable;
import java.util.LinkedList;
import java.util.List;

public class HashTable<K, V> {

    private static class Entry<K, V> {
        K key;
        V value;

        Entry(K key, V value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public String toString() {
            return key + " = " + value;
        }
    }

    private final List<Entry<K, V>>[] table;
    private int size;

    @SuppressWarnings("не проверенная")
    public HashTable(int capacity) {
        table = new List[capacity];

        for (int i = 0; i < capacity; i++) {
            table[i] = new LinkedList<>();
        }

        size = 0;
    }

    private int hash(K key) {
        return Math.abs(key.hashCode()) % table.length;
    }

    public void put(K key, V value) {
        int index = hash(key);

        for (Entry<K, V> entry : table[index]) {
            if (entry.key.equals(key)) {
                entry.value = value;
                return;
            }
        }

        table[index].add(new Entry<>(key, value));
        size++;
    }

    public V get(K key) {
        int index = hash(key);

        for (Entry<K, V> entry : table[index]) {
            if (entry.key.equals(key)) {
                return entry.value;
            }
        }

        return null;
    }

    public boolean containsKey(K key) {
        int index = hash(key);

        for (Entry<K, V> entry : table[index]) {
            if (entry.key.equals(key)) {
                return true;
            }
        }

        return false;
    }

    public boolean remove(K key) {
        int index = hash(key);

        for (Entry<K, V> entry : table[index]) {
            if (entry.key.equals(key)) {
                table[index].remove(entry);
                size--;
                return true;
            }
        }

        return false;
    }

    public int size() {
        return size;
    }

    public void printTable() {
        System.out.println("Хэш таблица:");

        for (int i = 0; i < table.length; i++) {
            System.out.print("Индекс " + i + ": ");

            if (table[i].isEmpty()) {
                System.out.println("Пусто");
            } else {
                for (Entry<K, V> entry : table[i]) {
                    System.out.print("(" + entry.key + " = " + entry.value + ") ");
                }
                System.out.println();
            }
        }
    }
}
